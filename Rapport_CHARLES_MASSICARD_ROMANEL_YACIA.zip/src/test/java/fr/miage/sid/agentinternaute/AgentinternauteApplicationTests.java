package fr.miage.sid.agentinternaute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgentinternauteApplicationTests {

	@Test
	void contextLoads() {
	}

}
