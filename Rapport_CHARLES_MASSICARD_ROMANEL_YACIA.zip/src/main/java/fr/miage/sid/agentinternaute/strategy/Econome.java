package fr.miage.sid.agentinternaute.strategy;

import org.json.JSONArray;
import org.json.JSONObject;

import fr.miage.sid.agentinternaute.entity.Profile;

public class Econome {

	public JSONObject economeResponse(JSONObject response, Profile profil) {
	
		boolean pref = profil.isPreferDownloadsForVideos();
	
		JSONArray oeuvres = response.getJSONArray("oeuvres");
		JSONArray offres = response.getJSONArray("abonnements");
		
		
		// Si il prefère le téléchargement 
		if(pref) {
			System.out.println("L'utilisateur préfère le téléchargement");
			return( this.getMinPrix(oeuvres));
			
		}else {
			JSONObject choixOeuvre = this.getMinPrix(oeuvres);
			JSONObject choixOffre = this.getMinPrix(offres);
			
			if (choixOeuvre.getDouble("prix") >= choixOffre.getDouble("prix")) {
				return choixOffre;
			}
			else {
				return choixOeuvre;
			}
		}
			
	}
	
	public JSONObject getMinPrix(JSONArray elements) {
		
		JSONObject choix = new JSONObject();
		Double prix_min = 0.0;
		int index_choix = 0;
		int j = 0;
		
		for (int i = 0; i < elements.length(); i++) {
			JSONObject element = (JSONObject) elements.get(i);
			// Première itération
			if( element.has("prix")) {
				if(i == j) {
					prix_min = element.getDouble("prix");
					index_choix = i;
				} else {
					
					if (prix_min > element.getDouble("prix")) {
						prix_min = element.getDouble("prix");
						index_choix = i;
					}	
					
				}
			} else {
				j++;
			}
		}
		
		choix = elements.getJSONObject(index_choix);
		
		return choix;
	}
	
}
