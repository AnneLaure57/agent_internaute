package fr.miage.sid.agentinternaute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgentinternauteApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgentinternauteApplication.class, args);
	}
}
